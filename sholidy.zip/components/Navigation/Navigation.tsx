'use client'

import React, { useState, useEffect } from 'react';
import './Navigation.css';

export interface NavigationItem {
  title: string;
  url: string;
  children?: NavigationItem[];
}

interface NavigationProps {
  isOpen: boolean;
  onClose: () => void;
}

// Mock navigation data - can be replaced with API call later
const mockNavigation: NavigationItem[] = [
  {
    title: 'Destinations',
    url: '/destinations',
    children: [
      { title: 'Africa', url: '/destinations/africa' },
      { title: 'Arctic & Antarctica', url: '/destinations/arctic' },
      { title: 'Asia', url: '/destinations/asia' },
      { title: 'Australia & New Zealand', url: '/destinations/australia' },
      { title: 'Central America', url: '/destinations/central-america' },
      { title: 'Europe', url: '/destinations/europe' },
      { title: 'Indian Ocean', url: '/destinations/indian-ocean' },
      { title: 'Middle East', url: '/destinations/middle-east' },
      { title: 'South America', url: '/destinations/south-america' },
      { title: 'South Pacific', url: '/destinations/south-pacific' },
      { title: 'US & Canada', url: '/destinations/us-canada' },
    ],
  },
  {
    title: 'Experiences',
    url: '/experiences',
    children: [
      { title: 'Active & Adventure', url: '/experiences/adventure' },
      { title: 'Beach', url: '/experiences/beach' },
      { title: 'Classics', url: '/experiences/classics' },
      { title: 'Family', url: '/experiences/family' },
      { title: 'Luxury', url: '/experiences/luxury' },
      { title: 'Safari & Wildlife', url: '/experiences/safari' },
      { title: 'Solo & Women Travel', url: '/experiences/solo' },
      { title: 'Wellness', url: '/experiences/wellness' },
    ],
  },
  {
    title: 'Inspiration',
    url: '/inspiration',
  },
  {
    title: 'Specials',
    url: '/specials',
  },
  {
    title: 'About',
    url: '/about',
  },
  {
    title: 'Contact',
    url: '/contact',
  },
];

const Navigation: React.FC<NavigationProps> = ({ isOpen, onClose }) => {
  const [menuItems, setMenuItems] = useState<NavigationItem[]>([]);
  const [activeSubmenu, setActiveSubmenu] = useState<string | null>(null);

  useEffect(() => {
    // Load navigation from mock data
    // TODO: Replace with API call when available
    setMenuItems(mockNavigation);
  }, []);

  // Add Home to menu items
  const allMenuItems: NavigationItem[] = [
    { title: 'Home', url: '/' },
    ...menuItems,
  ];

  const isActive = (url: string): boolean => {
    if (typeof window === 'undefined') return false;
    return window.location.pathname === url || window.location.pathname.startsWith(url + '/');
  };

  const handleSubmenuToggle = (title: string) => {
    setActiveSubmenu(activeSubmenu === title ? null : title);
  };

  return (
    <nav className={`navigation ${isOpen ? 'navigation--open' : ''}`}>
      <ul className="navigation__list">
        {allMenuItems.map((item) => (
          <li 
            key={item.url} 
            className={`navigation__item ${item.children ? 'navigation__item--has-children' : ''} ${activeSubmenu === item.title ? 'navigation__item--open' : ''}`}
          >
            <a
              href={item.url}
              className={`navigation__link ${isActive(item.url) ? 'navigation__link--active' : ''}`}
              onClick={(e) => {
                if (item.children) {
                  e.preventDefault();
                  handleSubmenuToggle(item.title);
                } else {
                  onClose();
                }
              }}
            >
              {item.title}
              {item.children && (
                <span className="navigation__arrow">
                  <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M3 4.5L6 7.5L9 4.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </span>
              )}
            </a>
            {item.children && (
              <ul className="navigation__submenu">
                {item.children.map((child: NavigationItem) => (
                  <li key={child.url} className="navigation__submenu-item">
                    <a
                      href={child.url}
                      className={`navigation__submenu-link ${isActive(child.url) ? 'navigation__submenu-link--active' : ''}`}
                      onClick={onClose}
                    >
                      {child.title}
                    </a>
                  </li>
                ))}
              </ul>
            )}
          </li>
        ))}
      </ul>
    </nav>
  );
};

export default Navigation;

